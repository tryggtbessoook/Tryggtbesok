import AccessibleLayout from "@/components/AccessibleLayout";

const Index = () => {
  return (
    <AccessibleLayout>
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center max-w-2xl mx-auto px-4">
          <header>
            <h1 className="text-4xl font-bold mb-4 text-foreground">
              Welcome to Your Accessible Web Application
            </h1>
          </header>
          
          <section aria-labelledby="intro-heading">
            <h2 id="intro-heading" className="sr-only">Introduction</h2>
            <p className="text-xl text-muted-foreground mb-6">
              This application has been built with accessibility in mind, following WCAG A level guidelines 
              to ensure it's usable by everyone, including people using assistive technologies.
            </p>
            
            <div className="space-y-4">
              <p className="text-muted-foreground">
                Ready to start building your amazing project? This foundation includes:
              </p>
              
              <ul className="text-left list-disc list-inside text-muted-foreground space-y-2 max-w-md mx-auto">
                <li>Semantic HTML structure with proper landmarks</li>
                <li>Keyboard navigation support</li>
                <li>Screen reader compatibility</li>
                <li>High contrast and reduced motion support</li>
                <li>Focus indicators for all interactive elements</li>
              </ul>
            </div>
          </section>
        </div>
      </div>
    </AccessibleLayout>
  );
};

export default Index;
