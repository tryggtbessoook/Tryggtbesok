import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import AccessibleLayout from "@/components/AccessibleLayout";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <AccessibleLayout>
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center max-w-md mx-auto px-4">
          <header>
            <h1 className="text-4xl font-bold mb-4 text-foreground">
              404 - Page Not Found
            </h1>
          </header>
          
          <section aria-labelledby="error-description">
            <h2 id="error-description" className="sr-only">Error Description</h2>
            <p className="text-xl text-muted-foreground mb-6">
              Sorry, the page you're looking for doesn't exist or has been moved.
            </p>
            
            <p className="text-muted-foreground mb-6">
              The requested URL <code className="bg-muted px-2 py-1 rounded text-sm">{location.pathname}</code> was not found on this server.
            </p>
          </section>
          
          <nav aria-label="Error page navigation">
            <Link 
              to="/" 
              className="inline-block bg-primary text-primary-foreground px-6 py-3 rounded-md font-medium hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 transition-colors no-underline"
              aria-describedby="home-link-description"
            >
              Return to Home Page
            </Link>
            <p id="home-link-description" className="sr-only">
              Navigate back to the main page of the application
            </p>
          </nav>
        </div>
      </div>
    </AccessibleLayout>
  );
};

export default NotFound;
