import { ReactNode } from 'react';

interface AccessibleLayoutProps {
  children: ReactNode;
  skipToContentId?: string;
}

const AccessibleLayout = ({ children, skipToContentId = "main-content" }: AccessibleLayoutProps) => {
  return (
    <div className="min-h-screen">
      {/* Skip to main content link for screen readers */}
      <a 
        href={`#${skipToContentId}`}
        className="skip-link"
        aria-label="Skip to main content"
      >
        Skip to main content
      </a>
      
      {/* Main content landmark */}
      <main 
        id={skipToContentId}
        role="main"
        aria-label="Main content"
        className="min-h-screen"
      >
        {children}
      </main>
    </div>
  );
};

export default AccessibleLayout;